// DK lang variables contributed by Jan Moelgaard

tinyMCE.addToLang('',{
preview_desc : 'Se siden'
});
