/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: tiny_mce.tar 1397 2006-09-07 07:55:53Z wei $ 
 */  

tinyMCE.addToLang('',{
preview_desc : 'Náhled'
});

