// French lang variables by Laurent Dran
// Modifi� par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
preview_desc : 'Pr�visualisation'
});
