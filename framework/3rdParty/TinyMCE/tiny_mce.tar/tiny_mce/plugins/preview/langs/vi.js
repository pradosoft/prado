// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
preview_desc : 'Xem trước'
});
