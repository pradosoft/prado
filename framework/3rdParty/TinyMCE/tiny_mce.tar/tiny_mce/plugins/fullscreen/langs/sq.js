// UK lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Modaliteti i ekranit te plote',
fullscreen_desc : 'Cakto modalitetin e ekranit te plote'
});