﻿// SR lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Mod celog ekrana',
fullscreen_desc : 'Menjanje moda punog ekrana'
});
