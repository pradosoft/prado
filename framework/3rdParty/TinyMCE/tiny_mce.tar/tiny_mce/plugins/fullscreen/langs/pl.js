// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('',{
fullscreen_title : 'Tryb pełnoekranowy',
fullscreen_desc : 'Przełącz w tryb pełnoekranowy'
});
