// SV lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Fullskärmsläge',
fullscreen_desc : 'Hoppa från/till fullskärmsläge'
});
