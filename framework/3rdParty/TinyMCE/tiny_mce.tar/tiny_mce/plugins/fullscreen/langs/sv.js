// SV lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Fullsk�rmsl�ge',
fullscreen_desc : 'Hoppa fr�n/till fullsk�rmsl�ge'
});
