// FI lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Kokoruututila',
fullscreen_desc : 'Vaihda kokoruututila p&auml;&auml;lle/pois'
});
