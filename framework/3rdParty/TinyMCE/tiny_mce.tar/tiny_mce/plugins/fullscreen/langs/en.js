// UK lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Fullscreen mode',
fullscreen_desc : 'Toggle fullscreen mode'
});
