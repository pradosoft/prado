// nb = Norwegian (bokm&aring;l) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
fullscreen_title : 'Fullskjerm tilstand',
fullscreen_desc : 'Hopp fra/til fullskjermtilstand'
});
