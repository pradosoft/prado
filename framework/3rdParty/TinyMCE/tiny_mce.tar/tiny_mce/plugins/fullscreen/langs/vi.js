﻿// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
fullscreen_title : 'Chế độ toàn màn hình',
fullscreen_desc : 'Chuyển đổi chế độ xem toàn màn hình'
});
