/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Oct. 17th, 2006
 * TinyMCE Version : 2.0.7
 */

tinyMCE.addToLang('',{
fullscreen_title : 'Modalit&agrave; a schermo intero',
fullscreen_desc : 'Abilita o disabilita la modalit&agrave; a schermo intero'
});
