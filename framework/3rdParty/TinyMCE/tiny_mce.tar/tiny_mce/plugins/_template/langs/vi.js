// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Đây chỉ là một cửa sổ bật ra cho mẫu',
template_desc : 'Đây chỉ là một nút cho mẫu'
});
