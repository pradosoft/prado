// Canadian French lang variables by Virtuelcom   last modification: 2005-06-15
// Modifi� par Normand Lamoureux le 2005-11-12

/* N'oubliez pas d'identifer les param�tres de langue ainsi: <votre plugin>_<un nom> */

tinyMCE.addToLang('',{
template_title : 'Texte qui appara�tra sous forme de titre dans la fen�tre pop-up de votre plugin',
template_desc : 'Texte qui appara�tra sous forme d\'info-bulle au survol du bouton de votre plugin'
});
