// nb = Norwegian (bokm&aring;l) lang variables by Knut B. Jacobsen

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'Dette er bare en template popup',
template_desc : 'Dette er bare en template knapp'
});
