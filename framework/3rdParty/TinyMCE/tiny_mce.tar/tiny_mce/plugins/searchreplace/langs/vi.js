// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Tìm',
searchreplace_searchnext_desc : 'Tìm tiếp',
searchreplace_replace_desc : 'Tìm/Thay thế',
searchreplace_notfound : 'Hoàn thành tìm kiếm. Không tìm thấy.',
searchreplace_search_title : 'Tìm',
searchreplace_replace_title : 'Tìm/Thay thế',
searchreplace_allreplaced : 'Đã thay thế hết.',
searchreplace_findwhat : 'Tìm gì',
searchreplace_replacewith : 'Thay thế bằng',
searchreplace_direction : 'Hướng',
searchreplace_up : 'Lên',
searchreplace_down : 'Xuống',
searchreplace_case : 'Phân biệt chữ hoa chữ thường',
searchreplace_findnext : 'Tìm&nbsp;tiếp',
searchreplace_replace : 'Thay&nbsp;thế',
searchreplace_replaceall : 'Thay&nbsp;tất&nbsp;cả',
searchreplace_cancel : 'Hủy&nbsp;bỏ'
});
