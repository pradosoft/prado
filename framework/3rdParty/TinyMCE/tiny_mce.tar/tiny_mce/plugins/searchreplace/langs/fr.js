// Franch lang variables by Laurent Dran
// Modifi� par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Rehercher',
searchreplace_searchnext_desc : 'Rehercher suivant',
searchreplace_replace_desc : 'Rechercher/Remplacer',
searchreplace_notfound : 'Recherche compl�t�e. La fin du document a �t� atteinte.',
searchreplace_search_title : 'Rechercher',
searchreplace_replace_title : 'Rechercher/Remplacer',
searchreplace_allreplaced : 'Action termin�e avec succ�s. Les remplacements\nont �t� faits dans l\'ensemble du document.',
searchreplace_findwhat : 'Trouver le mot',
searchreplace_replacewith : 'Remplacer avec',
searchreplace_direction : 'Direction',
searchreplace_up : 'Vers le haut',
searchreplace_down : 'Vers le bas',
searchreplace_case : 'Respecter la casse',
searchreplace_findnext : 'Suivant',
searchreplace_replace : 'Remplacer',
searchreplace_replaceall : 'Remplacer tout',
searchreplace_cancel : 'Annuler'
});
