// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('',{
searchreplace_search_desc : '查詢',
searchreplace_searchnext_desc : '再次查詢',
searchreplace_replace_desc : '查詢或替換',
searchreplace_notfound : '已完成查詢。沒找到指定的字串。',
searchreplace_search_title : '查詢',
searchreplace_replace_title : '查詢或替換',
searchreplace_allreplaced : '所有找到的字串已完成替換',
searchreplace_findwhat : '找什麼',
searchreplace_replacewith : '替換成',
searchreplace_direction : '方向',
searchreplace_up : '往上',
searchreplace_down : '向下',
searchreplace_case : '相符結果',
searchreplace_findnext : '查詢下個',
searchreplace_replace : '替換',
searchreplace_replaceall : '全部替換',
searchreplace_cancel : '取消'
});
