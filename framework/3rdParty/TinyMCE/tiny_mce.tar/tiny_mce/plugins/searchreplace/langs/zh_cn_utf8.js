// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('',{
searchreplace_search_desc : '查找',
searchreplace_searchnext_desc : '再次查找',
searchreplace_replace_desc : '查找/替换',
searchreplace_notfound : '搜索完毕，没有找到要查找的字符串。',
searchreplace_search_title : '查找',
searchreplace_replace_title : '查找/替换',
searchreplace_allreplaced : '所有符合条件的字符串已替换完毕。',
searchreplace_findwhat : '查找',
searchreplace_replacewith : '替换为',
searchreplace_direction : '方向',
searchreplace_up : '向上',
searchreplace_down : '向下',
searchreplace_case : '匹配大小写',
searchreplace_findnext : '查找下一个',
searchreplace_replace : '替换',
searchreplace_replaceall : '全部替换',
searchreplace_cancel : '取消'
});
