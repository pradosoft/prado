// FI lang variables by Tuomo Aura, Ateco.fi

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Etsi',
searchreplace_searchnext_desc : 'Etsi uudelleen',
searchreplace_replace_desc : 'Etsi/Korvaa',
searchreplace_notfound : 'Haku on p&auml;&auml;ttynyt. Haettua merkkijonoa ei l&ouml;ytynyt.',
searchreplace_search_title : 'Etsi',
searchreplace_replace_title : 'Etsi/Korvaa',
searchreplace_allreplaced : 'Kaikki esiintyneet hakutermit korvattiin.',
searchreplace_findwhat : 'Etsitt&auml;v&auml;',
searchreplace_replacewith : 'Korvaava',
searchreplace_direction : 'Suunta',
searchreplace_up : 'Yl&ouml;s',
searchreplace_down : 'Alas',
searchreplace_case : 'Sama kirjainkoko',
searchreplace_findnext : 'Etsi&nbsp;seuraava',
searchreplace_replace : 'Korvaa',
searchreplace_replaceall : 'Korvaa&nbsp;kaikki',
searchreplace_cancel : 'Peruuta'
});
