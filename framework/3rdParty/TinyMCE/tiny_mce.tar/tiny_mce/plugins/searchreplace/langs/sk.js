/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: sk.js,v 1.1 2005/11/22 20:56:44 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Nájdi',
searchreplace_searchnext_desc : 'Nájdi znova',
searchreplace_replace_desc : 'Nájdi/Nahradiť',
searchreplace_notfound : 'Vyhľadávanie ukončené. Reťazec nemusel byť nájdený.',
searchreplace_search_title : 'Nájdi',
searchreplace_replace_title : 'Nájdi/Nahradiť',
searchreplace_allreplaced : 'Všetky výskyty reťazca boly zmenené.',
searchreplace_findwhat : 'Nájsť',
searchreplace_replacewith : 'Nahradiť',
searchreplace_direction : 'Smer',
searchreplace_up : 'Nahor',
searchreplace_down : 'Dole',
searchreplace_case : 'Presná shoda',
searchreplace_findnext : 'Nájdi&nbsp;ďalší',
searchreplace_replace : 'Nahradiť',
searchreplace_replaceall : 'Nahradiť&nbsp;všetko',
searchreplace_cancel : 'Zrušiť'
});

