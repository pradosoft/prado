tinyMCE.addI18n('cs.searchreplace_dlg',{
searchnext_desc:"Naj\u00EDt dal\u0161\u00ED",
notfound:"Hled\u00E1n\u00ED bylo dokon\u010Deno. Hledan\u00FD text nebyl nalezen.",
search_title:"Naj\u00EDt",
replace_title:"Naj\u00EDt/nahradit",
allreplaced:"V\u0161echny v\u00FDskyty byly nahrazeny.",
findwhat:"Co hledat",
replacewith:"\u010C\u00EDm nahradit",
direction:"Sm\u011Br",
up:"Nahoru",
down:"Dol\u016F",
mcase:"Rozli\u0161ovat velikost",
findnext:"Naj\u00EDt dal\u0161\u00ED",
replace:"Nahradit",
replaceall:"Nahradit v\u0161e"
});