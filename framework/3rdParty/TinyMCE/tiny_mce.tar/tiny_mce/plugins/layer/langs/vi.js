﻿// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Thêm một layer mới',
forward_desc : 'Chuyển lên trước',
backward_desc : 'Chuyển xuống sau',
absolute_desc : 'Chuyển đổi xác định vị trí tuyệt đối',
content : 'Layer mới...'
});
