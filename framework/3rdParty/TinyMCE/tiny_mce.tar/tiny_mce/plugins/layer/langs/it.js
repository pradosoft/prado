/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Oct. 17th, 2006
 * TinyMCE Version : 2.0.7
 */

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Inserisci nuovo layer',
forward_desc : 'Sposta verso l\'alto',
backward_desc : 'Sposta verso il basso',
absolute_desc : 'Abilita o disabilita posizionamento assoluto',
content : 'Nuovo livello...'
});
