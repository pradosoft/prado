// RU lang variables UTF-8

tinyMCE.addToLang('layer',{
insertlayer_desc : 'Вставить новый слой',
forward_desc : 'Переместить вперед',
backward_desc : 'Переместить назад',
absolute_desc : 'Вкл / Выкл абсолютное позиционирование',
content : 'Новый слой...'
});
