﻿// SR lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Startuj proveru teksta',
iespell_download : "ieSpell nije detektovan. Kliknite OK za dolazak na download stranu."
});

