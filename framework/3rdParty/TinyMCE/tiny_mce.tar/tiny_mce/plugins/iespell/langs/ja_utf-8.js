﻿// Japanese utf-8 variables

tinyMCE.addToLang('',{
iespell_desc : 'スペルチェックをする',
iespell_download : "スペルチェックがない. OKをクリックすれば、ダウンロードへ行く."
});

