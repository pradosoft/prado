// SI lang variables ISO-8859-2

tinyMCE.addToLang('',{
iespell_desc : 'Za&#382;eni &#269;rkovanje',
iespell_download : "ieSpell ni zaznan. Kliknite OK za skok na stran za prenos."
});

