// JA lang variables

tinyMCE.addToLang('',{
iespell_desc : 'スペルチェックを行う',
iespell_download : "ieSpellが検出できませんでした。OKボタンを押してダウンロードページを表示してください"
});

