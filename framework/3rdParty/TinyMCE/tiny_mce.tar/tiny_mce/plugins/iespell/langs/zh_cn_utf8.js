// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('',{
iespell_desc : '运行拼写检查',
iespell_download : "未检测到 ieSpell 拼写检查，点击 OK 前往下载页面。"
});
