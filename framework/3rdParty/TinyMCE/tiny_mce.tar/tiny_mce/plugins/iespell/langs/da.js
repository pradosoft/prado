// DK lang variables contributed by Jan Moelgaard, John Dalsgaard and Bo Frederiksen.

tinyMCE.addToLang('',{
iespell_desc : 'Lav stavekontrol',
iespell_download : "ieSpell kan ikke findes. Klik p&aring; OK for at forts&aelig;tte til downloadsiden."
});

