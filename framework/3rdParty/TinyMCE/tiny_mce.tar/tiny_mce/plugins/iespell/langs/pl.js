// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl

tinyMCE.addToLang('',{
iespell_desc : 'Uruchom sprawdzanie pisowni',
iespell_download : "Nie wykryto pluginu, kliknij aby przejść do strony z pluginami."
});
