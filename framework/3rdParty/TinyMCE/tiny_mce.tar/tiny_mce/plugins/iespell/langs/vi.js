// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
iespell_desc : 'Chạy kiểm tra chính tả',
iespell_download : "Khong thấy kiểm tra chính tả ieSpell. Kích nút OK để đến trang tải xuống."
});

