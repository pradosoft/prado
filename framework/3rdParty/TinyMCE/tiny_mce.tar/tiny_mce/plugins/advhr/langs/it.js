/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Oct. 17th, 2006
 * TinyMCE Version : 2.0.7
 */

tinyMCE.addToLang('',{
insert_advhr_desc : 'Riga orizzontale',
insert_advhr_width : 'Larghezza',
insert_advhr_size : 'Altezza',
insert_advhr_noshade : 'Senza rilievo'
});
