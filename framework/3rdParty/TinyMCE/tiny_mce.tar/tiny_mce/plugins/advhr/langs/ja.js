// UK lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : '水平線の挿入',
insert_advhr_width : '幅',
insert_advhr_size : '高さ',
insert_advhr_noshade : '影をつけない'
});
