/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: tiny_mce.tar 1397 2006-09-07 07:55:53Z wei $ 
 */  

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vložiť/editovať vodorovný oddeľovač',
insert_advhr_width : 'Šírka',
insert_advhr_size : 'Výška',
insert_advhr_noshade : 'Nestieňovať'
});

