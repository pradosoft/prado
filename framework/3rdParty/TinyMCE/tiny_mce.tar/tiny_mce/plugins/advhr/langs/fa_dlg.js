tinyMCE.addI18n('fa.advhr_dlg',{
width:"\u0639\u0631\u0636",
size:"\u0627\u0631\u062A\u0641\u0627\u0639",
noshade:"\u0628\u062F\u0648\u0646 \u0633\u0627\u06CC\u0647"
});