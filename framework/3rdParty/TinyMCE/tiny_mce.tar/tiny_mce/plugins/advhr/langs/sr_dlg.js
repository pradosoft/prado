tinyMCE.addI18n('sr.advhr_dlg',{
width:"\u0160irina",
size:"Visina",
noshade:"Bez sjene"
});