// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
insert_advhr_desc : 'Đường thẳng ngang',
insert_advhr_width : 'Độ rộng',
insert_advhr_size : 'Chiều cao',
insert_advhr_noshade : 'Không có bóng đổ'
});
