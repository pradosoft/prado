// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
insert_advhr_desc : 'Ins&eacute;rer une r&egrave;gle horizontale styl&eacute;e',
insert_advhr_width : 'Largeur',
insert_advhr_size : 'Hauteur',
insert_advhr_noshade : 'Sans ombre'
});
