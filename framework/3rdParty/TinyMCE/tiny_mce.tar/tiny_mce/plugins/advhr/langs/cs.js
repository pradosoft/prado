/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: tiny_mce.tar 1397 2006-09-07 07:55:53Z wei $ 
 */  

tinyMCE.addToLang('',{
insert_advhr_desc : 'Vložit/editovat vodorovný oddělovač',
insert_advhr_width : 'Šířka',
insert_advhr_size : 'Výška',
insert_advhr_noshade : 'Nestínovat'
});

