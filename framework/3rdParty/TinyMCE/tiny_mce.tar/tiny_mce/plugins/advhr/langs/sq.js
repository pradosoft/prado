// AL lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Viszore horizontale',
insert_advhr_width : 'Gjeresi',
insert_advhr_size : 'Lartesi',
insert_advhr_noshade : 'Pa hije'
});