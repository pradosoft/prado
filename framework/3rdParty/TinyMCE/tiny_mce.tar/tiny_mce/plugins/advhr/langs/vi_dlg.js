tinyMCE.addI18n('vi.advhr_dlg',{
width:"Chi\u1EC1u r\u1ED9ng",
size:"Chi\u1EC1u cao",
noshade:"Kh\u00F4ng \u0111\u1ED5 b\u00F3ng"
});