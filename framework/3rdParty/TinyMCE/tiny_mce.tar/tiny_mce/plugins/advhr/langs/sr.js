// SR lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Horizontalno pravilo',
insert_advhr_width : '�irina',
insert_advhr_size : 'Visina',
insert_advhr_noshade : 'Bez senke'
});
