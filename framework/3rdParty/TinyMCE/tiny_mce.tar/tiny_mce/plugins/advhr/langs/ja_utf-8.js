﻿// 日本語 utf-8 lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : '平面の線を挿入・編集',
insert_advhr_width : '幅',
insert_advhr_size : '高さ',
insert_advhr_noshade : '影なし'
});
