// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Te pergjithshme',
tab_appearance : 'Pamja',
tab_advanced : 'E avancuar',
general : 'Te pergjithshme',
title : 'Titulli',
preview : 'Parashiko',
constrain_proportions : 'Ruaj Proporcionet',
langdir : 'Drejtimi i Gjuhes',
langcode : 'Kodi i gjuhes',
long_desc : 'Pershkirimi i gjate',
style : 'Stili',
classes : 'Klasat',
ltr : 'Nga e majta ne te djathte',
rtl : 'Nga e djathta ne te majte',
id : 'Id',
image_map : 'Harta e imazhit',
swap_image : 'Nderro imazhin',
alt_image : 'Imazhi alternativ',
mouseover : 'per maus mbi',
mouseout : 'per maus jashte',
misc : 'te ndryshme',
example_img : 'Pamja&nbsp;parashiko&nbsp;imazh',
missing_alt : 'Jeni i sigurt se do te vazhdoni pa nje pershkrim per imazhin?.'
});