﻿// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Generalno',
tab_appearance : 'Izgled',
tab_advanced : 'Napredno',
general : 'Generalno',
title : 'Naslov',
preview : 'Pregled',
constrain_proportions : 'Zadržavanje proporcija',
langdir : 'Jezički pravac',
langcode : 'Jezički kod',
long_desc : 'Duži opis linka',
style : 'Stil',
classes : 'Klase',
ltr : 'Levo ka desno',
rtl : 'Desno ka levo',
id : 'Id',
image_map : 'Mapa slike',
swap_image : 'Zamenjivanje slike',
alt_image : 'Alternativna slika',
mouseover : 'za mouse over',
mouseout : 'za mouse out',
misc : 'Razno',
example_img : 'Izgled&nbsp;pregled&nbsp;slika',
missing_alt : 'Da li ste sigurni da želite da nastavite bez uključivanja opisa slike? Bez toga slici se možda neće moći pristupiti od strane korisnika sa ogrničenjima, ili  od strane onih koji koriste tekstualne browsere, ili onih koji isključe slike u browseru.'
});
