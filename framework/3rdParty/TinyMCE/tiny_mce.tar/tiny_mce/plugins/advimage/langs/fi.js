// FI lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Yleiset',
tab_appearance : 'Ulkoasu',
tab_advanced : 'Lis&auml;asetukset',
general : 'Yleiset',
title : 'Otsikko',
preview : 'Esikatselu',
constrain_proportions : 'S&auml;ilyt&auml; mittasuhteet',
langdir : 'Kielen suunta',
langcode : 'Kielikoodi',
long_desc : 'Laajan kuvauksen linkki',
style : 'Tyyli',
classes : 'Luokat',
ltr : 'Vasemmalta oikealle',
rtl : 'Oikealta vasemmalle',
id : 'Id',
image_map : 'Kuvakartta',
swap_image : 'Kuvan vaihto',
alt_image : 'Vaihda kuvaa hiiren tullessa kuvan p&auml;&auml;lle',
mouseover : 'Osoittimen ollessa kuvan p&auml;&auml;ll&auml;',
mouseout : 'Osoittimen poistuessa kuvan p&auml;&auml;lt&auml;',
misc : 'Sekalaiset asetukset',
example_img : 'Appearance&nbsp;preview&nbsp;image',
missing_alt : 'Oletko varma ett� haluat lis�t� kuvan ilman kuvan selitett�? Selite auttaa ihmisi� joilla on terveydellisi� rajoitteita. T�m� auttaa my�s mik�li selaimesta on kuvien n�ytt� pois p��lt�, kuten esimerkiksi tekstiselaimissa kuvan tilalla n�ytet��n sen selite.'
});