// SE lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'Generella inställningar',
tab_appearance : 'Visuella inställningar',
tab_advanced : 'Avancerade inställningar',
general : 'Generella',
title : 'Titel',
preview : 'Förhandsgranskning',
constrain_proportions : 'Behåll proportionerna',
langdir : 'Skriftriktning',
langcode : 'Språkkod',
long_desc : 'Lång beskrivning',
style : 'Stil',
classes : 'Stilmallsklasser',
ltr : 'Vänster till höger',
rtl : 'Höger till vänster',
id : 'Id',
image_map : 'Bildkarta',
swap_image : 'Byt bild',
alt_image : 'Alternativ bild',
mouseover : 'när pekaren går över',
mouseout : 'när pekaren går utanför',
misc : 'Övrigt',
example_img : 'Förhandsgranskningsbild',
missing_alt : 'Är du säker på att du vill fortsätta utan att skriva en bildbeskrivning. Utan en alternativ beskrivning är bilden inte handikappanpassad.'
});
