// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl

tinyMCE.addToLang('',{
paste_text_desc : 'Wklej jako czysty tekst',
paste_text_title : 'U�yj CTRL+V na klawiaturze, aby wklei� tekst do okna.',
paste_text_linebreaks : 'Zachowaj �amanie linii',
paste_word_desc : 'Wklej z Worda',
paste_word_title : 'U�yj CTRL+V na klawiaturze, aby wklei� tekst do okna.',
selectall_desc : 'Zaznacz wszystko'
});