// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('',{
paste_text_desc : '作为纯文本粘贴',
paste_text_title : '使用快捷键 CTRL+V 将文本本粘贴到以下窗口中',
paste_text_linebreaks : '保留换行符',
paste_word_desc : '从Word粘贴',
paste_word_title : '使用快捷键 CTRL+V 将文本粘贴到以下窗口',
selectall_desc : '全选'
});
