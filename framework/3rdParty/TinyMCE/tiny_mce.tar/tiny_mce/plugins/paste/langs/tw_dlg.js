tinyMCE.addI18n('tw.paste_dlg',{
text_title:"\u5C07\u8907\u88FD(CTRL + C)\u7684\u5167\u5BB9\u8CBC\u4E0A(CTRL + V)\u5230\u8996\u7A97\u3002",
text_linebreaks:"\u4FDD\u7559\u63DB\u884C\u7B26\u865F",
word_title:"\u5C07\u8907\u88FD(CTRL + C)\u7684\u5167\u5BB9\u8CBC\u4E0A(CTRL + V)\u5230\u8996\u7A97\u3002"
});