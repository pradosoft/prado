tinyMCE.addI18n('ro.paste_dlg',{
text_title:"Folosi\u0163i CTRL+V pentru a lipi \u00EEn aceast\u0103 zon\u0103.",
text_linebreaks:"Pastreaza linii noi.",
word_title:"Folosi\u0163i CTRL+V pentru a lipi \u00EEn aceast\u0103 zon\u0103."
});