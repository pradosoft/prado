tinyMCE.addI18n('gl.paste_dlg',{
text_title:"Use CTRL+V no teclado pra pega-lo texto na vent\u00E1.",
text_linebreaks:"Manter salto de li\u00F1as",
word_title:"Use CTRL+V no teclado pra pega-lo texto na vent\u00E1."
});