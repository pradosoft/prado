/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: tiny_mce.tar 1397 2006-09-07 07:55:53Z wei $ 
 */  

tinyMCE.addToLang('',{
paste_text_desc : 'Vložiť neformatovaný text',
paste_text_title : 'Použi CTRL + V na klávesnici pre vloženie textu do okna.',
paste_text_linebreaks : 'Nechaj prerušenie riadkov',
paste_word_desc : 'Vložiť text s aplikáce Word',
paste_word_title : 'Použi CTRL + V na klávesnici pre vloženie textu do okna.',
selectall_desc : 'Označiť všetko'
});

