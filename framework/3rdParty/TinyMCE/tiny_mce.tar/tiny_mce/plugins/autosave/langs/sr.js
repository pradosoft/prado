﻿// SR lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Promene koje ste napravili biće izgubljene ako pređete na drugu stranu.'
});
