/**
 * Slovak lang variables 
 * encoding: utf-8
 * 
 * @author Vladimir VASIL vvasil@post.sk
 *    
 * $Id: tiny_mce.tar 1397 2006-09-07 07:55:53Z wei $ 
 */  

tinyMCE.addToLang('',{
autosave_unload_msg : 'Zmeny, ktoré ste urobyl(a) budú stratené, ak opustíte túto stránku.'
});

