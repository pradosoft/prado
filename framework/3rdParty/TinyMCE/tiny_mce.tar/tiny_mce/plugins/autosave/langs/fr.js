// Traduit par Normand Lamoureux le 2005-11-12

tinyMCE.addToLang('',{
autosave_unload_msg : 'Vos modifications seront perdues si vous quittez cette page.'
});
