/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: tiny_mce.tar 1397 2006-09-07 07:55:53Z wei $ 
 */  

tinyMCE.addToLang('',{
autosave_unload_msg : 'Změny, které jste udělal(a) budou ztraceny, jestliže opustíte tuto stránku.'
});

