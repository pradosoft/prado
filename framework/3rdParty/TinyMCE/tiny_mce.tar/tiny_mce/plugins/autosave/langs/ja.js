// JAlang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'ページを移動すると編集中の文章は失われます。'
});
