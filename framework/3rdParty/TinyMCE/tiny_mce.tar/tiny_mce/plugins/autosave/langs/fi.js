// EN lang variables

tinyMCE.addToLang('',{
autosave_unload_msg : 'Tekem�si muutokset menetet��n jos poistut t�lt� sivulta.'
});
