// nn = Norwegian (nynorsk) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('save',{
desc : 'Lagre'
});
