/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.5 2006/01/11 14:25:49 spocke Exp $ 
 */  

tinyMCE.addToLang('',{
save_desc : 'Uložit'
});

