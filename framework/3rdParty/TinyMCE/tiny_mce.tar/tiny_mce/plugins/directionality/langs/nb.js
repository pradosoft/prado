// nb = Norwegian (bokm&aring;l) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Retning fra venstre mot h&oslash;yre',
directionality_rtl_desc : 'Retning fra h&oslash;yre mot venstre'
});
