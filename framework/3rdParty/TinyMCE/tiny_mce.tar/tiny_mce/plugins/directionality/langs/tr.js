// TR lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Y�n soldan sa�a',
directionality_rtl_desc : 'Y�n sa�dan sola'
});
