﻿// SR lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Pravac levo ka desno',
directionality_rtl_desc : 'Pravac desno ka levo'
});
