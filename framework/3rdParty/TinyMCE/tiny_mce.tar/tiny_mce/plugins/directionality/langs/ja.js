// JA lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : '表示方向：左から右へ',
directionality_rtl_desc : '表示方向：右から左へ'
});
