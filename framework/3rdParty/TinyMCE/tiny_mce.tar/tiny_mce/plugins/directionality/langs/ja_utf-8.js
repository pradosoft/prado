﻿// Japanese unicode (utf-8)

tinyMCE.addToLang('',{
directionality_ltr_desc : '左から右へ',
directionality_rtl_desc : '右から左へ'
});
