// FI lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Suunta vasemmalta oikealle',
directionality_rtl_desc : 'Suunta oikealta vasemmalle'
});
