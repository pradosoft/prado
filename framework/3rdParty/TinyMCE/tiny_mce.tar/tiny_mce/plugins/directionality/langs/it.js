/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Oct. 17th, 2006
 * TinyMCE Version : 2.0.7
 */

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Direzione da sinistra a destra',
directionality_rtl_desc : 'Direzione da destra a sinistra'
});
