// SV lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Riktning fr�n v�nster till h�ger',
directionality_rtl_desc : 'Riktning fr�n h�ger till v�nster'
});
