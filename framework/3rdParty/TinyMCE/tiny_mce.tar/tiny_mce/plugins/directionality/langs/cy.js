// UK lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Cyfeiriad chwith i\'r dde',
directionality_rtl_desc : 'Cyfeiriad dde i\'r chwith'
});
