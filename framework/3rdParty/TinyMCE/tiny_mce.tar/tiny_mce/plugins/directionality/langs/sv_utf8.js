// SV lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Riktning från vänster till höger',
directionality_rtl_desc : 'Riktning från höger till vänster'
});
