﻿// Japanese utf-8 variables

tinyMCE.addToLang('flash',{
title : '挿入・編集フラッシュ',
desc : '挿入・編集フラッシュ',
file : 'フラッシュ (.swf)',
size : 'サイズ',
list : 'フラッシュのファイル',
props : 'フラッシュのプロパティ',
general : '一般'
});
