// UK lang variables

tinyMCE.addToLang('flash',{
title : 'Mewnosod/golygu Ffilm Flash',
desc : 'Mewnosod/golygu Ffilm Flash',
file : 'Ffeil Flash (.swf)',
size : 'Maint',
list : 'Ffeiliau Flash',
props : 'Priodoleddau Flash',
general : 'Cyffredinol'
});
