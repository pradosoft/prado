// UK lang variables

tinyMCE.addToLang('flash',{
title : 'Nderfut / ndrysho dokument Flash',
desc : 'Nderfut / ndrysho dokument Flash',
file : 'Dokument Flash (.swf)',
size : 'Madhesia',
list : 'Dokumenta Flash',
props : 'Te dhanat e dokumentit Flash',
general : 'Te pergjithshme'
});