/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: tiny_mce.tar 1397 2006-09-07 07:55:53Z wei $ 
 */  

tinyMCE.addToLang('flash',{
title : 'Vlo�it / editovat Flash',
desc : 'Vlo�it / editovat Flash',
file : 'Flash soubor (.swf)',
size : 'Velikost',
list : 'Flash soubory',
props : 'Flash nastaven�',
general : 'Obecn�'
});
