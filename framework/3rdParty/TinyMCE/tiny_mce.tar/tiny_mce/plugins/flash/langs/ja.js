// JA lang variables

tinyMCE.addToLang('flash',{
title : 'Flashの挿入',
desc : 'Flashの挿入',
file : 'Flashファイル(.swf)',
size : 'サイズ',
list : 'Flashファイル',
props : 'Flashの設定',
general : '全般'
});
