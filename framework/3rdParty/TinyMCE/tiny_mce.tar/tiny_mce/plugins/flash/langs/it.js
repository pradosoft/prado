/**
 * IT lang variables
 * 
 * Author : Luciano Vernaschi <luciano@virgilio.it>
 * Last Updated : Oct. 17th, 2006
 * TinyMCE Version : 2.0.7
 */

tinyMCE.addToLang('flash',{
title : 'Inserisci o modifica oggetto Flash',
desc : 'Inserisci o modifica oggetto Flash',
file : 'File Flash (.swf)',
size : 'Dimensioni',
list : 'Lista file',
props : 'Propriet&agrave;',
general : 'Generale'
});
