﻿// SR lang variables

tinyMCE.addToLang('flash',{
title : 'Ubacivanje / menjanje Flash Filma',
desc : 'Ubacivanje / menjanje Flash Filma',
file : 'Flash-Fajl (.swf)',
size : 'Veličina',
list : 'Flash fajlovi',
props : 'Flash podešavanja',
general : 'Generalno'
});
