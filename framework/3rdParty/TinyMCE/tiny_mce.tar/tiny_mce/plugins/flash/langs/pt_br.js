/**
 * pt_br lang variables
 * Brazilian Portuguese
 *
 * Author
 * Revision and modifications:
 *           Marcio Barbosa (mpg) <mpg@mpg.com.br>
 * First Release : November 26, 2005 - TinyMCE Version : 2.0RC4
 * Last Updated : November 20, 2006 - TinyMCE Version : 2.0.8
 */
tinyMCE.addToLang('flash',{
title : 'Inserir / editar Arquivo Flash',
desc : 'Inserir / editar Arquivo Flash',
file : 'Arquivo Flash (.swf)',
size : 'Tamanho',
list : 'Lista de arquivos Flash',
props : 'Propriedades do Flash',
general : 'Geral'
});
