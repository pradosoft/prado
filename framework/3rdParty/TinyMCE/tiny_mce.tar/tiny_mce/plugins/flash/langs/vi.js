// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('flash',{
title : 'Thêm/sửa phim flash',
desc : 'Thêm/sửa phim flash',
file : 'File flash (.swf)',
size : 'Kích thước',
list : 'File flash',
props : 'Thuộc tính flash',
general : 'Chung'
});
