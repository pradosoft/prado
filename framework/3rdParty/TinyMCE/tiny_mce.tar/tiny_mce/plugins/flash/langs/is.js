// Iceland lang variables by Johannes Birgir Jensson

tinyMCE.addToLang('flash',{
title : 'B&aelig;ta vi&eth; / breyta Flash-mynd',
desc : 'B&aelig;ta vi&eth; / breyta Flash-mynd',
file : 'Flash-skr&aacute; (.swf)',
size : 'St&aelig;r&eth;',
list : 'Flash skr&aacute;r',
props : 'Flash stillingar',
general : 'Almennt'
});
