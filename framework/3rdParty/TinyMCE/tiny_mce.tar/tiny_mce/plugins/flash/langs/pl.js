// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// fixed by lemiel 14.11.2005

tinyMCE.addToLang('flash',{
title : 'Wstaw/edytuj film flash',
desc : 'Wstaw/edytuj film flash',
file : 'Plik flash (.swf)',
size : 'Rozmiar',
list : 'Pliki flash',
props : 'Właściwości flash',
general : 'Główne'
});
