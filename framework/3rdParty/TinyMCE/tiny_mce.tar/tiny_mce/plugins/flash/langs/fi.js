// FI lang variables

tinyMCE.addToLang('flash',{
title : 'Lis&auml;&auml; / muokkaa Flash animaatio',
desc : 'Lis&auml;&auml; / muokkaa Flash animaatio',
file : 'Flash-tiedosto (.swf)',
size : 'Koko',
list : 'Flash tiedostot',
props : 'Flash ominaisuudet',
general : 'Yleiset'
});
