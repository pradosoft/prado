// HE lang variables by Liron Newman, http://eesh.net

tinyMCE.addToLang('',{
zoom_prefix : '&#230;&aring;�'
});
