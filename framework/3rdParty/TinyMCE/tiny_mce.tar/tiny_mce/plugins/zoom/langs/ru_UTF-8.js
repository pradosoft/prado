// RU UTF-8 lang variables

tinyMCE.addToLang('',{
zoom_prefix : 'масштаб'
});
