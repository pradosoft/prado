/**
 * Czech lang variables 
 * encoding: utf-8
 *  
 * $Id: cs.js,v 1.1 2006/01/11 14:35:10 spocke Exp $ 
 */  


tinyMCE.addToLang('',{
zoom_prefix : 'Měřítko zobrazení'
});

