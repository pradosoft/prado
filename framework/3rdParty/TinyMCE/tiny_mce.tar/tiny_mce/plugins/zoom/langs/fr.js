// Traduit par Normand Lamoureux le 2005-11-12

tinyMCELang['lang_zoom_prefix'] = 'Augmenter la taille';