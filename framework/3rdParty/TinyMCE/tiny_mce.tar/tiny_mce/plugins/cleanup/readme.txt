This is a experimental plugin and the contents of this plugin will be moved into the TinyMCE code ones it's stable enough.
