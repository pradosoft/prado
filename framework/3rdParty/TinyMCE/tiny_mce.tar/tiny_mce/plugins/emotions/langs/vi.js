// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('emotions',{
title : 'Thêm biểu cảm',
desc : 'Biểu&nbsp;cảm',
cool : 'Tuyệt',
cry : 'Khóc',
embarassed : 'Bối&nbsp;rối',
foot_in_mouth : 'Chân&nbsp;trong&nbsp;miệng',
frown : 'Cau&nbsp;mày',
innocent : 'Ngây&nbsp;thơ',
kiss : 'Hôn',
laughing : 'Cười',
money_mouth : 'Ngậm&nbsp;tiền',
sealed : 'Dán&nbsp;miệng',
smile : 'Mỉm&nbsp;cười',
surprised : 'Ngạc&nbsp;nhiên',
tongue_out : 'Thè&nbsp;lưỡi',
undecided : 'Chưa&nbsp;quyết&nbsp;định',
wink : 'Nháy&nbsp;mắt',
yell : 'La&nbsp;hét'
});
