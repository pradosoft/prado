// FI lang variables

tinyMCE.addToLang('Hymi&ouml;t',{
title : 'Lis&auml;&auml; hymi&ouml;',
desc : 'Hymi&ouml;',
cool : 'Cooli',
cry : 'Surullinen',
embarassed : 'Nolostunut',
foot_in_mouth : 'Jalka suussa',
frown : 'Otsa rypyss&auml;',
innocent : 'Viaton',
kiss : 'Suudelma',
laughing : 'Naurava',
money_mouth : 'Rahasuu',
sealed : 'Sinet&ouml;ity',
smile : 'Hymyilev&auml;',
surprised : 'Yll&auml;ttynyt',
tongue_out : 'Kieli ulkona',
undecided : 'P&auml;&auml;tt&auml;m&auml;t&ouml;n',
wink : 'Silm&auml;&auml; iskev&auml;',
yell : 'Huutaa'
});
