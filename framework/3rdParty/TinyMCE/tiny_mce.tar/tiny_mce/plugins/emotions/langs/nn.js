// nn = Norwegian (nynorsk) lang variables by Knut B. Jacobsen

tinyMCE.addToLang('emotions',{
title : 'Lim inn f&oslash;lelse',
desc : 'F&oslash;lelser',
cool : 'Cool',
cry : 'Gr&aring;ter',
embarassed : 'Sjenert',
foot_in_mouth : 'Fot i munnen',
frown : 'Lei seg',
innocent : 'Uskyldig',
kiss : 'Kyss',
laughing : 'Ler',
money_mouth : 'Penger i munnen',
sealed : 'Hemmelig',
smile : 'Glad',
surprised : 'Overrasket',
tongue_out : 'Rekke tunge',
undecided : 'Betenkt',
wink : 'Fl&oslash;rt',
yell : 'Skrikende'
});
