// Simplified Chinese lang variables contributed by TinyMCE_China_Team ( tinymce_china {AT} yahoogroups {DOT} com ).
// visit our homepage at: http://www.cube316.net/tinymce/ for more information.

tinyMCE.addToLang('emotions',{
title : '插入表情',
desc : '表情',
cool : '酷',
cry : '哭',
embarassed : '尴尬',
foot_in_mouth : 'Foot in mouth',
frown : '皱眉',
innocent : '无辜',
kiss : '亲吻',
laughing : '大笑',
money_mouth : 'Money mouth',
sealed : '保密',
smile : '微笑',
surprised : '惊讶',
tongue_out : '吐舌',
undecided : '犹豫',
wink : '眨眼',
yell : '大叫'
});