// RU lang variables UTF-8

tinyMCE.addToLang('emotions',{
title : 'Вставить смайлик',
desc : 'Смайлики',
cool : 'Cool',
cry : 'Плач',
embarassed : 'Embarassed',
foot_in_mouth : 'Foot in mouth',
frown : 'Нахмуренность',
innocent : 'Святой',
kiss : 'Поцелуй',
laughing : 'Смех',
money_mouth : 'Money mouth',
sealed : 'Заклеенный',
smile : 'Улыбка',
surprised : 'Сюрприз',
tongue_out : 'Высунутый язык',
undecided : 'Undecided',
wink : 'Wink',
yell : 'Yell'
});
