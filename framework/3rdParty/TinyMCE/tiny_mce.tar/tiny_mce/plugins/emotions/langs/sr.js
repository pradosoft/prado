﻿// SR lang variables

tinyMCE.addToLang('emotions',{
title : 'Ubacivanje smajlija',
desc : 'Smajliji',
cool : 'Kul',
cry : 'Plače',
embarassed : 'Sramota',
foot_in_mouth : 'Noga u ustima',
frown : 'Mršti se',
innocent : 'Nevin',
kiss : 'Poljubac',
laughing : 'Smeje se',
money_mouth : 'Novac u ustima',
sealed : 'Zapečaćen',
smile : 'Smeje se',
surprised : 'Iznenađen',
tongue_out : 'Plezi se',
undecided : 'Neodlučan',
wink : 'Namiguje',
yell : 'Viče'
});
