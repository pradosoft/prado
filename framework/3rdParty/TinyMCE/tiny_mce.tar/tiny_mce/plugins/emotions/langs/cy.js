// UK lang variables

tinyMCE.addToLang('emotions',{
title : 'Mewnosod gwenoglun',
desc : 'Gwenogluniau',
cool : 'C&#373;l',
cry : 'Cr&iuml;o',
embarassed : 'Cywilydd',
foot_in_mouth : 'Troed yn y ceg',
frown : 'Gwgu',
innocent : 'Diniwed',
kiss : 'Sws',
laughing : 'Chwerthin',
money_mouth : 'Ceg arian',
sealed : 'Seliwyd',
smile : 'Gw&ecirc;n',
surprised : 'Synnu',
tongue_out : 'Tafod allan',
undecided : 'Penagored',
wink : 'Winc',
yell : 'Gwaedd'
});
