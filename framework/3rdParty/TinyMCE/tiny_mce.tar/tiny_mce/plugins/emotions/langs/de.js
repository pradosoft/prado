// DE lang variables

tinyMCE.addToLang('emotions',{
title : 'Emotion einf&uuml;gen',
desc : 'Emotions',
cool : 'Cool',
cry : 'Weinen',
embarassed : 'Besch&auml;mt',
foot_in_mouth : 'Fettn&auml;pfchen',
frown : 'Missbilligen',
innocent : 'Unschuldig',
kiss : 'Kuss',
laughing : 'Lachanfall',
money_mouth : 'Geld im Kopf',
sealed : 'Besiegelt',
smile : 'L&auml;cheln',
surprised : '&Uuml;berrascht',
tongue_out : 'Zunge ausstrecken',
undecided : 'Unentschieden',
wink : 'Winken',
yell : 'Schreien'
});
