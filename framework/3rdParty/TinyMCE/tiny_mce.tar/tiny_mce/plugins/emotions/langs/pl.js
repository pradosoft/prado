// PL lang variables
// fixed by Wooya
// http://www.mfusion.prv.pl
// lemiel 25.10.2005

tinyMCE.addToLang('emotions',{
title : 'Wstaw emotikonkę',
desc : 'Emotikonki',
cool : 'Super',
cry : 'Płaczę',
embarassed : 'Zażenowanie',
foot_in_mouth : 'Trzepię jęzorem',
frown : 'Marszczę brew',
innocent : 'Niewinny',
kiss : 'Pocałunek',
laughing : 'śmiech',
money_mouth : 'Zasady życiowe',
sealed : 'Zaplombowane usta',
smile : 'Uśmiech',
surprised : 'Zaskoczenie',
tongue_out : 'Pokazuję język',
undecided : 'Niezdecydowanie',
wink : 'Perskie oko',
yell : 'Wycie'
});
