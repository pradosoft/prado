// SE lang variables

tinyMCE.addToLang('',{
print_desc : 'Skriv ut'
});
