// TR lang variables

tinyMCE.addToLang('',{
print_desc : 'Yazd�r'
});
