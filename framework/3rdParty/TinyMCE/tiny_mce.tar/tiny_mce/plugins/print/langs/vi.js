// Vietnamese lang variables - Ðỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
print_desc : 'In'
});
