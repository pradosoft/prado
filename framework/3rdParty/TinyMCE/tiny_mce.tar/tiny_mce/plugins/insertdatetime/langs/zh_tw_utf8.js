// Traditional Chinese UTF-8; Twapweb Site translated; twapweb_AT_gmail_DOT_com
// 繁體中文 UTF-8 ；數位應用坊製作； twapweb_AT_gmail_DOT_com

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y/%m/%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : '插入日期',
inserttime_desc : '插入時間',
inserttime_months_long : new Array("一月", "二月", "三月", "四月", "五月", "六月", "七月", "八月", "九月", "十月", "十一月", "十二月"),
inserttime_months_short : new Array("一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"),
inserttime_day_long : new Array("星期日", "星期一", "星期二", "星期三", "星期四", "星期五", "星期六", "星期日"),
inserttime_day_short : new Array("日", "一", "二", "三", "四", "五", "六", "日")
});
