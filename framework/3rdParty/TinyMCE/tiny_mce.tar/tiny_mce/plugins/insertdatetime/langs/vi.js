// Vietnamese lang variables - Đỗ Xuân Tiến - tiendx2002@yahoo.com Việt hóa

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d-%m-%Y',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Thêm ngày',
inserttime_desc : 'Thêm thời gian',
inserttime_months_long : new Array("Tháng Một", "Tháng Hai", "Tháng Ba", "Tháng Tư", "Tháng Năm", "Tháng Sáu", "Tháng Bảy", "Tháng Tám", "Tháng Chín", "Tháng Mười", "Tháng M.Một", "Tháng M.Hai"),
inserttime_months_short : new Array("ThMột", "ThHai", "ThBa", "ThTư", "ThNăm", "ThSáu", "ThBảy", "ThTám", "ThChín", "ThMười", "ThM.Một", "ThM.Hai"),
inserttime_day_long : new Array("Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy", "Chủ nhật"),
inserttime_day_short : new Array("CN", "T2", "T3", "T4", "T5", "T6", "T7", "CN")
});
