// UK lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d-%m-%Y',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Nderfut daten',
inserttime_desc : 'Nderfut oren',
inserttime_months_long : new Array("Janar", "Shkurt", "Mars", "Prill", "Maj", "Qershor", "Korrik", "Gusht", "Shtator", "Tetor", "Nentor", "Dhjetor"),
inserttime_months_short : new Array("Jan", "Shk", "Mar", "Pri", "Maj", "Qer", "Kor", "Gus", "Sht", "Tet", "Nen", "Dhj"),
inserttime_day_long : new Array("E diel", "E hene", "E marte", "E merkure", "E enjte", "E Premter", "E shtune", "E diel"),
inserttime_day_short : new Array("Die", "Hen", "Mar", "Mer", "Enj", "Pre", "Sht", "Die")
});