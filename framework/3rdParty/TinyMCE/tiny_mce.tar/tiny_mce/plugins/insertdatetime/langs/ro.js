// RO lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d-%m-%Y',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Insereaz&#259; data',
inserttime_desc : 'Insereaz&#259; ora',
inserttime_months_long : new Array("Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie", "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"),
inserttime_months_short : new Array("Ian", "Feb", "Mar", "Apr", "Mai", "Iun", "Iul", "Aug", "Sep", "Oct", "Nov", "Dec"),
inserttime_day_long : new Array("Duminic&#259;", "Luni", "Mar&#355;i", "Miercuri", "Joi", "Vineri", "S&#226;mb&#259;t&#259;", "Duminic&#259;"),
inserttime_day_short : new Array("Dum", "Lun", "Mar", "Mie", "Joi", "Vin", "S&#226;m", "Dum")
});
