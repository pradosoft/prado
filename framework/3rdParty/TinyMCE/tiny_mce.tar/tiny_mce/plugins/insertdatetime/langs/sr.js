﻿// SR lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d.%m.%Y',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Ubacivanje datuma',
inserttime_desc : 'Ubacivanje vremena',
inserttime_months_long : new Array("Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar"),
inserttime_months_short : new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Avg", "Sep", "Okt", "Nov", "Dec"),
inserttime_day_long : new Array("Nedelja", "Ponedeljak", "Utorak", "Sreda", "Četvrtak", "Petak", "Subota", "Nedelja"),
inserttime_day_short : new Array("Ned", "Pon", "Uto", "Sre", "Čet", "Pet", "Sub", "Ned")
});
